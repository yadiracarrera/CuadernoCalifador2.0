import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Download, 
  RefreshCcw, 
  Database, 
  Check, 
  X, 
  Calendar, 
  Users, 
  Settings, 
  Calculator, 
  AlertCircle,
  Link2,
  ChevronRight,
  HelpCircle,
  FileCode
} from 'lucide-react';

import { AcademicColumn, Student, ClassSettings, SyncConfig, AttendanceStatus } from './types';
import ConnectionGuide from './components/ConnectionGuide';
import Dashboard from './components/Dashboard';
import { exportHtmlReport } from './utils/exportHtml';

// Seed mock data for realistic initial state so the user isn't greeted with a blank screen
const INITIAL_STUDENTS: Student[] = [
  {
    id: 'stud-1',
    name: 'Alvarez Mendoza, Lucía',
    grades: {
      'col-p1-act1': 9.5,
      'col-p1-act2': 10,
      'col-p1-exam': 8.5,
      'col-p2-act1': 9.0,
      'col-p2-exam': 9.5,
      'col-p3-act1': 10,
      'col-p3-exam': 9.0,
    },
    attendance: {
      '2026-06-01': 'P',
      '2026-06-02': 'P',
      '2026-06-03': 'P',
      '2026-06-04': 'P',
      '2026-06-05': 'P',
    }
  },
  {
    id: 'stud-2',
    name: 'Castillo Ruiz, Fernando',
    grades: {
      'col-p1-act1': 7.0,
      'col-p1-act2': 6.5,
      'col-p1-exam': 5.0,
      'col-p2-act1': 8.0,
      'col-p2-exam': 6.0,
      'col-p3-act1': 7.5,
      'col-p3-exam': 5.5,
    },
    attendance: {
      '2026-06-01': 'P',
      '2026-06-02': 'R',
      '2026-06-03': 'A',
      '2026-06-04': 'P',
      '2026-06-05': 'P',
    }
  },
  {
    id: 'stud-3',
    name: 'García López, Elena',
    grades: {
      'col-p1-act1': 8.5,
      'col-p1-act2': 9.0,
      'col-p1-exam': 9.5,
      'col-p2-act1': 9.0,
      'col-p2-exam': 9.0,
      'col-p3-act1': 9.5,
      'col-p3-exam': 10,
    },
    attendance: {
      '2026-06-01': 'P',
      '2026-06-02': 'P',
      '2026-06-03': 'P',
      '2026-06-04': 'P',
      '2026-06-05': 'P',
    }
  },
  {
    id: 'stud-4',
    name: 'Jiménez Sosa, Raúl',
    grades: {
      'col-p1-act1': 4.0,
      'col-p1-act2': 5.5,
      'col-p1-exam': 4.5,
      'col-p2-act1': 5.0,
      'col-p2-exam': 4.0,
      'col-p3-act1': 6.0,
      'col-p3-exam': 5.0,
    },
    attendance: {
      '2026-06-01': 'A',
      '2026-06-02': 'A',
      '2026-06-03': 'R',
      '2026-06-04': 'P',
      '2026-06-05': 'A',
    }
  }
];

const INITIAL_COLUMNS: AcademicColumn[] = [
  // Parcial 1
  { id: 'col-p1-act1', name: 'ACT 01', type: 'actividad', parcial: 1, maxScore: 10 },
  { id: 'col-p1-act2', name: 'ACT 02', type: 'actividad', parcial: 1, maxScore: 10 },
  { id: 'col-p1-exam', name: 'EXAM', type: 'evaluacion', parcial: 1, maxScore: 10 },
  // Parcial 2
  { id: 'col-p2-act1', name: 'ACT 01', type: 'actividad', parcial: 2, maxScore: 10 },
  { id: 'col-p2-exam', name: 'EXAM', type: 'evaluacion', parcial: 2, maxScore: 10 },
  // Parcial 3
  { id: 'col-p3-act1', name: 'ACT 01', type: 'actividad', parcial: 3, maxScore: 10 },
  { id: 'col-p3-exam', name: 'EXAM', type: 'evaluacion', parcial: 3, maxScore: 10 },
];

const INITIAL_ATTENDANCE_DATES = [
  '2026-06-01',
  '2026-06-02',
  '2026-06-03',
  '2026-06-04',
  '2026-06-05'
];

export default function App() {
  // Main State and configuration persistence 
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('eduplan_students');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [columns, setColumns] = useState<AcademicColumn[]>(() => {
    const saved = localStorage.getItem('eduplan_columns');
    return saved ? JSON.parse(saved) : INITIAL_COLUMNS;
  });

  const [attendanceDates, setAttendanceDates] = useState<string[]>(() => {
    const saved = localStorage.getItem('eduplan_attendance_dates');
    return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE_DATES;
  });

  const [settings, setSettings] = useState<ClassSettings>(() => {
    const saved = localStorage.getItem('eduplan_settings');
    return saved ? JSON.parse(saved) : {
      gradingScale: 10,
      weightActividades: 40,
      weightEvaluaciones: 60
    };
  });

  const [syncConfig, setSyncConfig] = useState<SyncConfig>(() => {
    const saved = localStorage.getItem('eduplan_sync_config');
    return saved ? JSON.parse(saved) : {
      appsScriptUrl: '',
      lastSync: null,
      status: 'disconnected'
    };
  });

  // Current active view tab
  const [activeTab, setActiveTab] = useState<'p1' | 'p2' | 'p3' | 'asistencia' | 'dashboard' | 'guide'>('p1');

  // Modal and Form States
  const [showAddStudent, setShowAddStudent] = useState(false);
  const [newStudentName, setNewStudentName] = useState('');
  
  const [showAddColumn, setShowAddColumn] = useState(false);
  const [newColName, setNewColName] = useState('');
  const [newColType, setNewColType] = useState<'actividad' | 'evaluacion'>('actividad');
  const [newColMaxScore, setNewColMaxScore] = useState(10);

  const [showAddDate, setShowAddDate] = useState(false);
  const [newDateStr, setNewDateStr] = useState(() => {
    const d = new Date();
    return d.toISOString().split('T')[0];
  });

  const [showSettings, setShowSettings] = useState(false);
  const [tempWeightAct, setTempWeightAct] = useState(settings.weightActividades);
  const [tempWeightEval, setTempWeightEval] = useState(settings.weightEvaluaciones);
  const [tempScale, setTempScale] = useState<10 | 100>(settings.gradingScale);

  const [inputAppsScriptUrl, setInputAppsScriptUrl] = useState(syncConfig.appsScriptUrl);
  const [syncMessage, setSyncMessage] = useState<{ text: string; isError: boolean } | null>(null);

  // Sync state variables automatic local storage backing
  useEffect(() => {
    localStorage.setItem('eduplan_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('eduplan_columns', JSON.stringify(columns));
  }, [columns]);

  useEffect(() => {
    localStorage.setItem('eduplan_attendance_dates', JSON.stringify(attendanceDates));
  }, [attendanceDates]);

  useEffect(() => {
    localStorage.setItem('eduplan_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('eduplan_sync_config', JSON.stringify(syncConfig));
  }, [syncConfig]);

  // Map parcial numbers to tab state string
  const getTabParcial = (): 1 | 2 | 3 => {
    if (activeTab === 'p2') return 2;
    if (activeTab === 'p3') return 3;
    return 1;
  };

  // 1. ADD ALUMNO
  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentName.trim()) return;

    const newStudent: Student = {
      id: 'stud-' + Date.now(),
      name: newStudentName.trim(),
      grades: {},
      attendance: {}
    };

    setStudents(prev => [...prev, newStudent]);
    setNewStudentName('');
    setShowAddStudent(false);
  };

  // 2. DELETE ALUMNO
  const handleDeleteStudent = (id: string, name: string) => {
    if (window.confirm(`¿Está seguro de que desea eliminar al estudiante "${name}"? Se borrarán sus calificaciones y asistencias.`)) {
      setStudents(prev => prev.filter(s => s.id !== id));
    }
  };

  // 3. ADD ACADEMIC COLUMN
  const handleAddColumn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newColName.trim()) return;

    const parcialNum = getTabParcial();
    const newColumn: AcademicColumn = {
      id: 'col-' + Date.now(),
      name: newColName.trim().toUpperCase(),
      type: newColType,
      parcial: parcialNum,
      maxScore: newColMaxScore
    };

    setColumns(prev => [...prev, newColumn]);
    setNewColName('');
    setShowAddColumn(false);
  };

  // 4. DELETE ACADEMIC COLUMN
  const handleDeleteColumn = (colId: string, colName: string) => {
    if (window.confirm(`¿Desea eliminar la columna "${colName}" de evaluaciones? Se eliminarán los datos asignados en esta celda.`)) {
      setColumns(prev => prev.filter(c => c.id !== colId));
      // Clean up students grades
      setStudents(prev => prev.map(s => {
        const updatedGrades = { ...s.grades };
        delete updatedGrades[colId];
        return { ...s, grades: updatedGrades };
      }));
    }
  };

  // 5. ADD ATTENDANCE DATE
  const handleAddDate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDateStr) return;
    if (attendanceDates.includes(newDateStr)) {
      alert('Esta fecha ya está registrada.');
      return;
    }

    setAttendanceDates(prev => [...prev, newDateStr].sort());
    setShowAddDate(false);
  };

  // 6. DELETE ATTENDANCE DATE
  const handleDeleteDate = (dateStr: string) => {
    if (window.confirm(`¿Eliminar la fecha de asistencia "${dateStr}"?`)) {
      setAttendanceDates(prev => prev.filter(d => d !== dateStr));
      setStudents(prev => prev.map(s => {
        const updatedAttendance = { ...s.attendance };
        delete updatedAttendance[dateStr];
        return { ...s, attendance: updatedAttendance };
      }));
    }
  };

  // 7. TOGGLE ATTENDANCE CELL STATE
  const handleToggleAttendance = (studentId: string, dateStr: string) => {
    const statusCycle: AttendanceStatus[] = ['P', 'A', 'R', 'J'];
    setStudents(prev => prev.map(student => {
      if (student.id === studentId) {
        const current = student.attendance[dateStr] || 'P';
        const currentIndex = statusCycle.indexOf(current);
        const nextStatus = statusCycle[(currentIndex + 1) % statusCycle.length];
        return {
          ...student,
          attendance: {
            ...student.attendance,
            [dateStr]: nextStatus
          }
        };
      }
      return student;
    }));
  };

  // 8. UPDATE DIRECT CELL GRADE INPUT
  const handleGradeUpdate = (studentId: string, colId: string, valueStr: string, maxScore: number) => {
    let numericValue = valueStr === '' ? 0 : parseFloat(valueStr);
    if (isNaN(numericValue)) numericValue = 0;
    
    // Bounds check
    if (numericValue < 0) numericValue = 0;
    if (numericValue > maxScore) numericValue = maxScore;

    setStudents(prev => prev.map(s => {
      if (s.id === studentId) {
        return {
          ...s,
          grades: {
            ...s.grades,
            [colId]: numericValue
          }
        };
      }
      return s;
    }));
  };

  // 9. UPDATE GLOBAL EVALUATION SYSTEM SETTINGS
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempWeightAct + tempWeightEval !== 100) {
      alert('La suma de ponderaciones debe dar exactamente 100%.');
      return;
    }
    setSettings({
      gradingScale: tempScale,
      weightActividades: tempWeightAct,
      weightEvaluaciones: tempWeightEval
    });
    setShowSettings(false);
  };

  // 10. GENERATE AND DOWNLOAD THE STATIC REPORT HTML
  const downloadReportHtml = () => {
    try {
      const htmlText = exportHtmlReport(students, columns, settings, attendanceDates);
      const element = document.createElement('a');
      const file = new Blob([htmlText], { type: 'text/html' });
      element.href = URL.createObjectURL(file);
      element.download = 'Reporte_Evaluaciones_EduPlan.html';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    } catch (err) {
      alert('Error al exportar reporte HTML: ' + err);
    }
  };

  // 11. GOOGLE SHEETS / APPS SCRIPT SYNC OPERATION (TRIGGER POST)
  const syncToGoogleSheets = async () => {
    if (!inputAppsScriptUrl.trim()) {
      setSyncMessage({
        text: 'Por favor, ingrese una URL válida de Google Apps Script en la sección de Google Sheets.',
        isError: true
      });
      return;
    }

    setSyncConfig(prev => ({ ...prev, status: 'syncing' }));
    setSyncMessage(null);

    try {
      // Package actual React state to synchronous JSON block
      const payload = {
        students,
        columns,
        attendanceDates,
        settings,
        timestamp: new Date().toISOString()
      };

      const response = await fetch(inputAppsScriptUrl.trim(), {
        method: 'POST',
        mode: 'no-cors', // Apps Script web apps are hosted on redirection; no-cors allows pushing data easily.
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });

      // Since 'no-cors' doesn't return readable success bytes (returns opaque), 
      // we check that we reached here without exception and flag connected
      localStorage.setItem('apps_script_backup_url', inputAppsScriptUrl.trim());
      
      setSyncConfig({
        appsScriptUrl: inputAppsScriptUrl.trim(),
        lastSync: new Date().toLocaleTimeString() + ' ' + new Date().toLocaleDateString(),
        status: 'connected'
      });
      
      setSyncMessage({
        text: '¡Sincronización enviada con éxito! Compruebe su Google Sheets, los reportes se procesarán en instantes.',
        isError: false
      });
    } catch (error: any) {
      setSyncConfig(prev => ({ 
        ...prev, 
        status: 'error',
        errorMessage: error.message 
      }));
      setSyncMessage({
        text: 'Fallo al conectar con Google Sheets: ' + error.message,
        isError: true
      });
    }
  };

  // 12. PULL STATE FROM GOOGLE SHEETS (REVERSE RETRIEVE)
  const pullFromGoogleSheets = async () => {
    if (!inputAppsScriptUrl.trim()) {
      alert('Por favor, ingrese primero la URL de su Google Apps Script.');
      return;
    }

    setSyncConfig(prev => ({ ...prev, status: 'syncing' }));
    
    try {
      const resp = await fetch(inputAppsScriptUrl.trim());
      const resData = await resp.json();
      if (resData.success && resData.data) {
        const fetched = resData.data;
        if (fetched.students) setStudents(fetched.students);
        if (fetched.columns) setColumns(fetched.columns);
        if (fetched.attendanceDates) setAttendanceDates(fetched.attendanceDates);
        if (fetched.settings) setSettings(fetched.settings);
        
        setSyncConfig({
          appsScriptUrl: inputAppsScriptUrl.trim(),
          lastSync: 'Descargado: ' + new Date().toLocaleTimeString(),
          status: 'connected'
        });
        alert('¡Datos de Google Sheets descargados y restaurados localmente con éxito!');
      } else {
        alert('El script respondió pero no hay datos inicializados aún en la pestaña BD_SISTEMA.');
        setSyncConfig(prev => ({ ...prev, status: 'connected' }));
      }
    } catch (err: any) {
      setSyncConfig(prev => ({ ...prev, status: 'error' }));
      alert('Error de conexión al obtener datos: ' + err.message);
    }
  };

  // Calculate detailed student stats in real time for Table rows
  const getProcessedStudentGrades = (student: Student, pNum: 1 | 2 | 3) => {
    const pCols = columns.filter(c => c.parcial === pNum);
    const actCols = pCols.filter(c => c.type === 'actividad');
    const evalCols = pCols.filter(c => c.type === 'evaluacion');

    let actSum = 0;
    let actCount = 0;
    actCols.forEach(col => {
      const score = student.grades[col.id] !== undefined ? student.grades[col.id] : 0;
      actSum += col.maxScore > 0 ? (score / col.maxScore) * settings.gradingScale : 0;
      actCount++;
    });
    const actAvg = actCount > 0 ? actSum / actCount : 0;

    let evalSum = 0;
    let evalCount = 0;
    evalCols.forEach(col => {
      const score = student.grades[col.id] !== undefined ? student.grades[col.id] : 0;
      evalSum += col.maxScore > 0 ? (score / col.maxScore) * settings.gradingScale : 0;
      evalCount++;
    });
    const evalAvg = evalCount > 0 ? evalSum / evalCount : 0;

    let finalParcial = 0;
    if (actCount > 0 && evalCount > 0) {
      finalParcial = (actAvg * (settings.weightActividades / 100)) + (evalAvg * (settings.weightEvaluaciones / 100));
    } else if (actCount > 0) {
      finalParcial = actAvg;
    } else if (evalCount > 0) {
      finalParcial = evalAvg;
    }

    // Attendance
    let pCount = 0;
    let totalActDates = 0;
    attendanceDates.forEach(d => {
      const stat = student.attendance[d];
      if (stat === 'P' || stat === 'R' || stat === 'J' || stat === 'A') {
        totalActDates++;
      }
      if (stat === 'P') pCount += 1;
      else if (stat === 'R') pCount += 0.5;
      else if (stat === 'J') pCount += 1; // Justificado cuenta completo para asistencia escolar
    });
    const attendancePercentage = totalActDates > 0 ? (pCount / totalActDates) * 100 : 100;

    return {
      actAvg,
      evalAvg,
      finalParcial,
      attendancePercentage
    };
  };

  // Parcial level list variables
  const currentParcial = getTabParcial();
  const currentColumnsOfParcial = columns.filter(c => c.parcial === currentParcial);
  
  // Overall class averages for KPIs in main board view
  const getClassAveragesGlobal = () => {
    if (students.length === 0) return { avgGrade: 0, avgAttendance: 0, approvals: 0, risk: 0 };
    
    let gradeSum = 0;
    let attendanceSum = 0;
    let passingCount = 0;
    let riskCount = 0;

    const limitPass = settings.gradingScale === 10 ? 6.0 : 60;

    students.forEach(st => {
      // Calculate final trimester average (mean of all 3 partials)
      const pGrades = [1, 2, 3].map(p => {
        const stats = getProcessedStudentGrades(st, p as 1 | 2 | 3);
        return stats.finalParcial;
      });
      const finalTrimester = (pGrades[0] + pGrades[1] + pGrades[2]) / 3;
      gradeSum += finalTrimester;

      // Attendance
      let attended = 0;
      let registered = 0;
      attendanceDates.forEach(d => {
        const s = st.attendance[d];
        if (s === 'P') attended += 1;
        else if (s === 'R') attended += 0.5;
        else if (s === 'J') attended += 1;
        if (s) registered++;
      });
      const attRate = registered > 0 ? (attended / registered) * 100 : 100;
      attendanceSum += attRate;

      if (finalTrimester >= limitPass) {
        passingCount++;
      } else {
        riskCount++;
      }
    });

    return {
      avgGrade: gradeSum / students.length,
      avgAttendance: attendanceSum / students.length,
      approvals: passingCount,
      risk: riskCount
    };
  };

  const classKpis = getClassAveragesGlobal();

  return (
    <div className="flex justify-center bg-[#f1f5f9] min-h-screen py-6 px-4">
      
      {/* 
        This is the fixed Geometric Balance viewport wrapper styled 
        perfectly in sync with the user's HTML model. 
      */}
      <div id="geometric-balance-root" className="flex flex-col w-full max-w-5xl bg-[#f8fafc] text-slate-800 border-4 sm:border-8 border-slate-200 rounded-3xl shadow-xl overflow-hidden min-h-[780px]">
        
        {/* HEADER SECTION */}
        <header className="flex flex-col sm:flex-row items-center justify-between px-6 py-4 bg-white border-b border-slate-200 shadow-sm gap-4">
          <div className="flex items-center gap-4 w-full sm:w-auto">
            <div className="w-10 h-10 bg-indigo-600 rounded flex items-center justify-center text-white font-bold shrink-0">
              EP
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                EduPlan Pro <span className="text-indigo-600">v2.0</span>
              </h1>
              <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">
                Gestión Académica • Evaluaciones y Asistencia Trimestral
              </p>
            </div>
          </div>
          
          {/* Sincronización rápida y descarga */}
          <div className="flex flex-wrap gap-2 w-full sm:w-auto justify-end">
            <button 
              onClick={downloadReportHtml}
              id="download-html-report-header"
              className="px-3.5 py-2 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-xl text-xs font-bold border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
              title="Descargar reporte local en archivo HTML legible"
            >
              <Download className="h-3.5 w-3.5" />
              Reporte HTML
            </button>
            
            <button 
              onClick={() => {
                setActiveTab('guide');
                document.getElementById('instructions-section')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-3.5 py-2 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-xl text-xs font-bold border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <HelpCircle className="h-3.5 w-3.5 text-indigo-500" />
              Guía Sheets
            </button>

            <button 
              onClick={syncToGoogleSheets}
              id="sync-sheet-btn-header"
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RefreshCcw className={`h-3.5 w-3.5 ${syncConfig.status === 'syncing' ? 'animate-spin' : ''}`} />
              Sincronizar Sheets
            </button>
          </div>
        </header>

        {/* NAVIGATION TABS RAIL */}
        <nav className="flex bg-white overflow-x-auto border-b border-slate-200 scrollbar-none">
          <button 
            onClick={() => setActiveTab('p1')}
            className={`px-5 py-3 border-b-2 font-bold text-xs tracking-wider whitespace-nowrap transition-all uppercase cursor-pointer ${
              activeTab === 'p1' 
                ? 'border-indigo-600 text-indigo-600 bg-indigo-50/20' 
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            PARCIAL 1
          </button>
          <button 
            onClick={() => setActiveTab('p2')}
            className={`px-5 py-3 border-b-2 font-bold text-xs tracking-wider whitespace-nowrap transition-all uppercase cursor-pointer ${
              activeTab === 'p2' 
                ? 'border-indigo-600 text-indigo-600 bg-indigo-50/20' 
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            PARCIAL 2
          </button>
          <button 
            onClick={() => setActiveTab('p3')}
            className={`px-5 py-3 border-b-2 font-bold text-xs tracking-wider whitespace-nowrap transition-all uppercase cursor-pointer ${
              activeTab === 'p3' 
                ? 'border-indigo-600 text-indigo-600 bg-indigo-50/20' 
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            PARCIAL 3
          </button>
          <button 
            onClick={() => setActiveTab('asistencia')}
            className={`px-5 py-3 border-b-2 font-bold text-xs tracking-wider whitespace-nowrap transition-all uppercase cursor-pointer ${
              activeTab === 'asistencia' 
                ? 'border-indigo-600 text-indigo-600 bg-indigo-50/20' 
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            ASISTENCIA DIARIA
          </button>
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`px-5 py-3 border-b-2 font-bold text-xs tracking-wider whitespace-nowrap transition-all uppercase cursor-pointer ${
              activeTab === 'dashboard' 
                ? 'border-indigo-600 text-indigo-600 bg-indigo-50/20' 
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            DASHBOARD GRUPAL
          </button>
          <button 
            onClick={() => setActiveTab('guide')}
            className={`px-5 py-3 border-b-2 font-bold text-xs tracking-wider whitespace-nowrap transition-all uppercase cursor-pointer ${
              activeTab === 'guide' 
                ? 'border-indigo-600 text-indigo-600 bg-indigo-50/20' 
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            ENLACE GOOGLE SHEETS
          </button>

          {/* Quick status dot */}
          <div className="ml-auto hidden md:flex items-center gap-4 text-xs font-bold text-slate-400 px-6">
            <span className="flex items-center gap-1.5 whitespace-nowrap">
              <span className={`w-2.5 h-2.5 rounded-full ${syncConfig.status === 'connected' ? 'bg-green-500 animate-pulse' : 'bg-amber-500'}`}></span>
              Sheets: {syncConfig.status === 'connected' ? 'Enlazado' : 'Local (Storage)'}
            </span>
          </div>
        </nav>

        {/* GOOGLE SHEETS CONFIGURATION MINI-BAR */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 flex-grow">
            <Database className="h-4 w-4 text-slate-500 shrink-0" />
            <span className="font-bold text-slate-700 whitespace-nowrap">URL de Apps Script:</span>
            <input 
              type="text" 
              placeholder="https://script.google.com/macros/s/.../exec" 
              value={inputAppsScriptUrl}
              onChange={(e) => setInputAppsScriptUrl(e.target.value)}
              className="bg-white border border-slate-200 px-3 py-1.5 rounded-lg flex-grow max-w-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-[11px]"
            />
          </div>
          <div className="flex gap-2">
            <button 
              onClick={pullFromGoogleSheets}
              className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold rounded-lg transition-colors cursor-pointer"
              title="Descargar última versión salvada en Google Sheets"
            >
              Descargar Datos
            </button>
            <button 
              onClick={syncToGoogleSheets}
              className="px-3 py-1.5 bg-indigo-100 border border-indigo-200 hover:bg-indigo-200 text-indigo-800 font-bold rounded-lg transition-colors cursor-pointer"
            >
              Cargar y Sincronizar
            </button>
          </div>
        </div>

        {/* MAIN VIEWS CONTROLLER */}
        <main className="flex-1 flex flex-col p-6 overflow-hidden gap-4">
          
          {syncMessage && (
            <div className={`p-3.5 rounded-xl border text-xs flex gap-2 items-start ${
              syncMessage.isError 
                ? 'bg-red-50 border-red-100 text-red-800' 
                : 'bg-green-50 border-green-100 text-green-800'
            }`}>
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">{syncMessage.isError ? 'Atención' : 'Sincronización'}</p>
                <p className="mt-0.5">{syncMessage.text}</p>
              </div>
              <button onClick={() => setSyncMessage(null)} className="ml-auto hover:opacity-60 cursor-pointer">
                <X className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* PARCIAL TABS VIEW MODE (p1, p2, p3) */}
          {(activeTab === 'p1' || activeTab === 'p2' || activeTab === 'p3') && (
            <div className="flex-1 flex flex-col gap-4">
              
              {/* Toolbar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="flex flex-wrap gap-2">
                  <button 
                    onClick={() => setShowAddColumn(true)}
                    className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg border border-indigo-100 text-xs font-bold uppercase tracking-tight flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    + Añadir Actividad/Examen
                  </button>
                  <button 
                    onClick={() => setShowAddStudent(true)}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-200 text-xs font-bold uppercase tracking-tight flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    + Añadir Alumno
                  </button>
                  <button 
                    onClick={() => setShowSettings(true)}
                    className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-500 rounded-lg border border-slate-200 text-xs font-bold uppercase tracking-tight flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Settings className="h-3.5 w-3.5" />
                    Ponderación %
                  </button>
                </div>

                <div className="text-xs font-semibold text-slate-500 italic bg-white px-3.5 py-1.5 rounded-lg border border-slate-200 flex items-center gap-1 justify-center sm:justify-start">
                  <span>Asignatura: Control del Parcial - 3 Trimestrales</span>
                </div>
              </div>

              {/* STUDENTS ACADEMIC BOARD TABLE */}
              <div className="flex-1 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse min-w-[700px]">
                    <thead className="bg-slate-50">
                      <tr className="text-[10px] font-bold text-slate-500 uppercase tracking-widest border-b border-slate-200">
                        <th className="px-4 py-3.5 border-r border-slate-200 w-16 text-center">ID</th>
                        <th className="px-4 py-3.5 border-r border-slate-200 min-w-[200px]">Estudiante</th>
                        
                        {/* Dynamic Active Parcial Columns */}
                        {currentColumnsOfParcial.map(col => (
                          <th key={col.id} className="px-3 py-3.5 border-r border-slate-200 text-center w-28 relative group bg-indigo-50/10 hover:bg-indigo-50/40 transition-colors">
                            <div className="flex flex-col items-center">
                              <span className="text-[11px] font-bold text-slate-800 leading-none">{col.name}</span>
                              <span className="text-[8px] text-[indigo-600] mt-1 font-semibold tracking-normal uppercase">
                                {col.type === 'evaluacion' ? 'Examen' : 'Actv'} ({col.maxScore} pts)
                              </span>
                            </div>
                            
                            {/* Column deletion bubble */}
                            <button 
                              onClick={() => handleDeleteColumn(col.id, col.name)}
                              className="absolute -top-1.5 -right-1.5 bg-rose-500 text-white rounded-full p-0.5 shadow-md opacity-0 group-hover:opacity-100 transition-opacity duration-150 cursor-pointer"
                              title={`Eliminar columna ${col.name}`}
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </th>
                        ))}

                        {currentColumnsOfParcial.length === 0 && (
                          <th className="px-4 py-3.5 border-r border-slate-200 text-center italic text-[11px] text-slate-400">
                            Añada actividades o evaluaciones para calificar
                          </th>
                        )}

                        <th className="px-4 py-3.5 border-r border-slate-200 text-center w-24 bg-indigo-50 text-indigo-700">
                          PROMEDIO
                        </th>
                        <th className="px-4 py-3.5 border-r border-slate-200 text-center w-20">
                          ASIST %
                        </th>
                        <th className="px-4 py-3.5 text-center w-12">ACCIONES</th>
                      </tr>
                    </thead>
                    
                    <tbody className="text-sm divide-y divide-slate-100">
                      {students.map((student, idx) => {
                        const stats = getProcessedStudentGrades(student, currentParcial);
                        const isPassing = stats.finalParcial >= (settings.gradingScale === 10 ? 6.0 : 60);

                        return (
                          <tr key={student.id} className={`${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'} hover:bg-slate-100/40 transition-colors`}>
                            {/* Short student Number */}
                            <td className="px-4 py-3 font-mono text-xs text-slate-400 text-center border-r border-slate-100">
                              #{idx + 1}
                            </td>
                            
                            {/* Full Student Name */}
                            <td className="px-4 py-3 font-semibold text-slate-700 border-r border-slate-100">
                              {student.name}
                            </td>

                            {/* Inputs for dynamic grades */}
                            {currentColumnsOfParcial.map(col => {
                              const currentVal = student.grades[col.id];
                              return (
                                <td key={col.id} className="px-3 py-3.5 border-r border-slate-100 text-center">
                                  <div className="flex items-center justify-center gap-1">
                                    <input 
                                      type="number"
                                      step="0.1"
                                      min="0"
                                      max={col.maxScore}
                                      value={currentVal !== undefined ? currentVal : ''}
                                      onChange={(e) => handleGradeUpdate(student.id, col.id, e.target.value, col.maxScore)}
                                      placeholder="-"
                                      className="w-14 text-center bg-indigo-50/20 hover:bg-indigo-50/40 focus:bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-xs font-semibold py-1 rounded border border-transparent hover:border-slate-200"
                                    />
                                  </div>
                                </td>
                              );
                            })}

                            {currentColumnsOfParcial.length === 0 && (
                              <td className="px-4 py-3 border-r border-slate-100 text-center text-xs text-slate-400 italic">
                                Sin columnas
                              </td>
                            )}

                            {/* Calculated Parcial score */}
                            <td className="px-4 py-3 border-r border-slate-100 text-center bg-indigo-50/30 font-bold italic">
                              <span className={isPassing ? 'text-indigo-700' : 'text-rose-600'}>
                                {stats.finalParcial.toFixed(1)}
                              </span>
                            </td>

                            {/* Attendance % within current period */}
                            <td className="px-4 py-3 border-r border-slate-100 text-center text-xs">
                              <span className={`font-bold font-mono ${stats.attendancePercentage >= 80 ? 'text-emerald-600' : stats.attendancePercentage >= 60 ? 'text-amber-500' : 'text-rose-600'}`}>
                                {stats.attendancePercentage.toFixed(0)}%
                              </span>
                            </td>

                            {/* Action to delete student inline */}
                            <td className="px-4 py-3 text-center">
                              <button 
                                onClick={() => handleDeleteStudent(student.id, student.name)}
                                className="text-slate-400 hover:text-red-600 transition-colors p-1 rounded hover:bg-red-50 cursor-pointer"
                                title="Eliminar alumno de la lista"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}

                      {students.length === 0 && (
                        <tr>
                          <td colSpan={currentColumnsOfParcial.length + 5} className="py-12 text-center text-slate-400 text-sm italic">
                            No hay estudiantes cargados. ¡Añada uno nuevo usando el botón superior!
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* STATS KPIs FOOTER */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2">
                <div className="bg-indigo-600 text-white p-4 rounded-xl shadow-sm flex flex-col justify-center">
                  <span className="text-[10px] uppercase font-bold tracking-widest opacity-80">Promedio General</span>
                  <span className="text-2xl font-bold italic font-mono">{classKpis.avgGrade.toFixed(2)}</span>
                </div>
                
                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm flex flex-col justify-center">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400">Asistencia Prom.</span>
                  <span className="text-2xl font-bold italic text-slate-700 font-mono">{classKpis.avgAttendance.toFixed(1)}%</span>
                </div>
                
                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm flex flex-col justify-center">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400">Aprobados (Trim.)</span>
                  <span className="text-2xl font-bold italic text-slate-100 text-slate-700 font-mono">
                    {classKpis.approvals} / {students.length}
                  </span>
                </div>
                
                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm flex flex-col justify-center border-l-4 border-l-rose-500">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400">En Riesgo</span>
                  <span className="text-2xl font-bold italic text-rose-600 font-mono">
                    {classKpis.risk} / {students.length}
                  </span>
                </div>
              </div>

            </div>
          )}

          {/* ASISTENCIA DIARIA TAB VIEW MODE */}
          {activeTab === 'asistencia' && (
            <div className="flex-1 flex flex-col gap-4">
              
              {/* Toolbar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="flex flex-wrap gap-2">
                  <button 
                    onClick={() => setShowAddDate(true)}
                    className="px-3.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg border border-indigo-100 text-xs font-bold uppercase tracking-tight flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    + Registrar Nueva Fecha
                  </button>
                  <button 
                    onClick={() => setShowAddStudent(true)}
                    className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-200 text-xs font-bold uppercase tracking-tight flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    + Añadir Alumno
                  </button>
                </div>

                <div className="text-[10px] font-bold text-indigo-800 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded max-w-lg text-center">
                  ⚙️ TIP: Haga clic en las casillas circulares de asistencia para alternar: P (Presente) → A (Ausente) → R (Retardo) → J (Justificado) 
                </div>
              </div>

              {/* ATTENDANCE WORK BOARD TABLE */}
              <div className="flex-1 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse min-w-[600px]">
                    <thead className="bg-slate-50">
                      <tr className="text-[10px] font-bold text-slate-500 uppercase tracking-widest border-b border-slate-200">
                        <th className="px-4 py-3.5 border-r border-slate-200 w-16 text-center">ID</th>
                        <th className="px-4 py-3.5 border-r border-slate-200 min-w-[180px]">Estudiante</th>
                        
                        {/* Dynamic Active Dates Columns */}
                        {attendanceDates.map(dateStr => (
                          <th key={dateStr} className="px-2 py-3.5 border-r border-slate-200 text-center w-28 relative group bg-emerald-50/10 hover:bg-emerald-50/30 transition-colors">
                            <div className="flex flex-col items-center">
                              <span className="text-[10px] font-extrabold text-slate-800 leading-none">{dateStr.substring(5)}</span>
                              <span className="text-[8px] text-gray-400 mt-1 font-mono">{dateStr.substring(0, 4)}</span>
                            </div>
                            
                            {/* Delete date column icon */}
                            <button 
                              onClick={() => handleDeleteDate(dateStr)}
                              className="absolute -top-1.5 -right-1.5 bg-rose-500 text-white rounded-full p-0.5 shadow-md opacity-0 group-hover:opacity-100 transition-opacity duration-150 cursor-pointer"
                              title={`Eliminar fecha ${dateStr}`}
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </th>
                        ))}

                        {attendanceDates.length === 0 && (
                          <th className="px-4 py-3.5 border-r border-slate-200 text-center italic text-[11px] text-slate-400">
                            No hay fechas de asistencias registradas
                          </th>
                        )}

                        <th className="px-4 py-3.5 text-center w-24 bg-indigo-50 text-indigo-700">
                          % GRAL
                        </th>
                      </tr>
                    </thead>
                    
                    <tbody className="text-sm divide-y divide-slate-100">
                      {students.map((student, idx) => {
                        // Calc overall attendance percentages
                        let presentCount = 0;
                        let registeredCount = 0;
                        attendanceDates.forEach(d => {
                          const status = student.attendance[d];
                          if (status === 'P') presentCount += 1;
                          else if (status === 'R') presentCount += 0.5;
                          else if (status === 'J') presentCount += 1; // Justificado
                          
                          if (status) registeredCount += 1;
                        });
                        const rate = registeredCount > 0 ? (presentCount / registeredCount) * 100 : 100;

                        return (
                          <tr key={student.id} className={`${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'} hover:bg-slate-100/40 transition-colors`}>
                            {/* Index */}
                            <td className="px-4 py-3.5 font-mono text-xs text-slate-400 text-center border-r border-slate-100">
                              #{idx + 1}
                            </td>
                            
                            {/* Student name */}
                            <td className="px-4 py-3.5 font-semibold text-slate-700 border-r border-slate-100">
                              {student.name}
                            </td>

                            {/* Attendance cells triggers */}
                            {attendanceDates.map(dateStr => {
                              const currentStatus = student.attendance[dateStr] || 'A';
                              
                              let statusBg = 'bg-rose-100 text-rose-800 border-rose-200';
                              if (currentStatus === 'P') statusBg = 'bg-emerald-100 text-emerald-800 border-emerald-200';
                              else if (currentStatus === 'R') statusBg = 'bg-amber-100 text-amber-800 border-amber-200';
                              else if (currentStatus === 'J') statusBg = 'bg-violet-100 text-violet-800 border-violet-200';

                              return (
                                <td key={dateStr} className="px-2 py-2 border-r border-slate-100 text-center">
                                  <button
                                    onClick={() => handleToggleAttendance(student.id, dateStr)}
                                    className={`w-10 h-10 rounded-full border text-xs font-black shadow-sm flex items-center justify-center mx-auto transition-transform active:scale-95 cursor-pointer ${statusBg}`}
                                    title="Alternar entre Presente, Ausente, Retardo y Justificado"
                                  >
                                    {currentStatus}
                                  </button>
                                </td>
                              );
                            })}

                            {attendanceDates.length === 0 && (
                              <td className="px-4 py-3.5 border-r border-slate-100 text-center text-xs text-slate-400 italic">
                                Sin fechas registradas
                              </td>
                            )}

                            {/* Overall Attendance calculated cell */}
                            <td className="px-4 py-3.5 text-center bg-indigo-50/20 font-black font-mono">
                              <span className={rate >= 80 ? 'text-emerald-600' : rate >= 60 ? 'text-amber-500' : 'text-rose-600'}>
                                {rate.toFixed(0)}%
                              </span>
                            </td>
                          </tr>
                        );
                      })}

                      {students.length === 0 && (
                        <tr>
                          <td colSpan={attendanceDates.length + 3} className="py-12 text-center text-slate-400 text-sm italic">
                            No hay estudiantes asignados al sistema.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* DASHBOARD GRAPHICAL VIEW MODE */}
          {activeTab === 'dashboard' && (
            <Dashboard 
              students={students} 
              columns={columns} 
              settings={settings} 
              attendanceDates={attendanceDates} 
            />
          )}

          {/* DETAILED APPS SCRIPT AND GOOGLE SHEETS SETUP */}
          {activeTab === 'guide' && (
            <div className="space-y-6">
              <ConnectionGuide />
            </div>
          )}

        </main>

        {/* BOTTOM DESIGN DETAILED FOOTER */}
        <footer className="px-8 py-4 bg-slate-900 text-slate-400 flex flex-col md:flex-row justify-between items-center text-[10px] uppercase tracking-[0.2em] font-medium gap-2">
          <p>© 2026 EDUPLAN • AUTOMATED SYSTEM • GITHUB PAGES READY</p>
          <p className="flex items-center gap-1">
            <span className="w-2 h-2 bg-green-500 rounded-full inline-block animate-ping"></span>
            <span>STATUS: READY FOR HOSTING DEPLOYMENT</span>
          </p>
        </footer>

      </div>

      {/* ==================================== MODAL OVERLAYS AND FORMS ==================================== */}
      
      {/* 1. ADD NEW STUDENT MODAL */}
      {showAddStudent && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-150">
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <h3 className="font-extrabold text-slate-900 text-sm tracking-tight uppercase">Registrar Nuevo Alumno</h3>
              <button onClick={() => setShowAddStudent(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleAddStudent} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nombre Completo (Apellidos, Nombres)</label>
                <input 
                  type="text" 
                  value={newStudentName}
                  onChange={(e) => setNewStudentName(e.target.value)}
                  placeholder="Ej: Pérez García, Juan Carlos"
                  className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-semibold"
                  autoFocus
                />
              </div>
              <p className="text-[10px] text-slate-400">
                El alumno se añadirá automáticamente a las listas de los 3 parciales y asistencia diaria. Guarde datos localmente o sincronícelos con Sheets.
              </p>
              <div className="flex justify-end gap-2 pt-2">
                <button 
                  type="button" 
                  onClick={() => setShowAddStudent(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200 hover:bg-slate-200 transition"
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 transition shadow"
                >
                  Confirmar Alumno
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. ADD NEW ACADEMIC COLUMN MODAL */}
      {showAddColumn && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <h3 className="font-extrabold text-slate-900 text-sm tracking-tight uppercase">Añadir Actividad o Examen (Parcial {currentParcial})</h3>
              <button onClick={() => setShowAddColumn(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleAddColumn} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Identificador / Nombre corto</label>
                <input 
                  type="text" 
                  maxLength={15}
                  value={newColName}
                  onChange={(e) => setNewColName(e.target.value)}
                  placeholder="Ej: ACT 03, EXAM 2, TAREA 1"
                  className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-bold uppercase"
                  autoFocus
                />
              </div>
              
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tipo de instrumento académico</label>
                <select 
                  value={newColType}
                  onChange={(e: any) => setNewColType(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-semibold"
                >
                  <option value="actividad">Actividad / Tarea (Pondera para actividades)</option>
                  <option value="evaluacion">Evaluación / Examen (Pondera para exámenes)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Puntaje Máximo Posible</label>
                <input 
                  type="number" 
                  min={1} 
                  max={100} 
                  value={newColMaxScore}
                  onChange={(e) => setNewColMaxScore(parseInt(e.target.value) || 10)}
                  className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono font-semibold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button 
                  type="button" 
                  onClick={() => setShowAddColumn(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200 hover:bg-slate-200 transition"
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 transition shadow"
                >
                  Crear Columna
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. ADD REGISTERED DATE DIALOG */}
      {showAddDate && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <h3 className="font-extrabold text-slate-900 text-sm tracking-tight uppercase">Añadir Fecha de Asistencia</h3>
              <button onClick={() => setShowAddDate(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleAddDate} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Seleccionar Fecha</label>
                <input 
                  type="date"
                  value={newDateStr}
                  onChange={(e) => setNewDateStr(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button 
                  type="button" 
                  onClick={() => setShowAddDate(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200 hover:bg-slate-200 transition"
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  className="px-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl px-4 transition shadow"
                >
                  Añadir Registro
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. CLASSROOM PONDERATION SETTINGS CONFIGURATION */}
      {showSettings && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <h3 className="font-extrabold text-slate-900 text-sm tracking-tight uppercase">Configurar Escalas y Ponderaciones</h3>
              <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSaveSettings} className="p-6 space-y-4">
              
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Escala de Calificación</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                    <input 
                      type="radio" 
                      name="gradingScale" 
                      checked={tempScale === 10} 
                      onChange={() => setTempScale(10)} 
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    Escala Base 10 (Ej: 0.0 - 10.0)
                  </label>
                  <label className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                    <input 
                      type="radio" 
                      name="gradingScale" 
                      checked={tempScale === 100} 
                      onChange={() => setTempScale(100)} 
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    Escala Base 100 (Ej: 0 - 100)
                  </label>
                </div>
              </div>

              <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100 space-y-3">
                <p className="text-[10px] uppercase font-bold text-indigo-800 tracking-wider">Cálculo Ponderado de las Notas</p>
                
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Porcentaje de Actividades (%)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      min={0} 
                      max={100} 
                      value={tempWeightAct}
                      onChange={(e) => {
                        const val = parseInt(e.target.value) || 0;
                        setTempWeightAct(val);
                        setTempWeightEval(100 - val);
                      }}
                      className="w-20 bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-xs text-slate-800 font-mono font-bold"
                    />
                    <span className="text-xs text-slate-500 font-medium">Equivale al {tempWeightAct}% del promedio parcial.</span>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Porcentaje de Evaluaciones / Exámenes (%)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      min={0} 
                      max={100} 
                      value={tempWeightEval}
                      onChange={(e) => {
                        const val = parseInt(e.target.value) || 0;
                        setTempWeightEval(val);
                        setTempWeightAct(100 - val);
                      }}
                      className="w-20 bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-xs text-slate-800 font-mono font-bold"
                    />
                    <span className="text-xs text-slate-500 font-medium">Equivale al {tempWeightEval}% del promedio parcial.</span>
                  </div>
                </div>
              </div>

              <div className="text-[10px] text-slate-400">
                Al aplicar, las asistencias y los promedios se recalculan de forma dinámica en tiempo real sobre estas nuevas proporciones.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button 
                  type="button" 
                  onClick={() => setShowSettings(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200 hover:bg-slate-200 transition"
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 transition shadow"
                >
                  Guardar Configuración
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
