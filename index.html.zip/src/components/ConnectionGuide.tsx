import { useState } from 'react';
import { Clipboard, Check, FileText, Download, Laptop, Link } from 'lucide-react';
import { APPS_SCRIPT_CODE } from '../utils/appsScriptCode';

export default function ConnectionGuide() {
  const [copied, setCopied] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(APPS_SCRIPT_CODE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadCode = () => {
    const element = document.createElement('a');
    const file = new Blob([APPS_SCRIPT_CODE], { type: 'text/javascript' });
    element.href = URL.createObjectURL(file);
    element.download = 'Codigo_AppsScript_Centralizador.js';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Section Header */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 p-6 md:p-8 text-white">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 p-2.5 rounded-xl">
            <Laptop className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight">Guía de Conexión a Google Sheets</h2>
            <p className="text-slate-300 text-sm mt-0.5">Siga estos sencillos pasos para almacenar datos en la nube y generar reportes mensuales en tiempo real.</p>
          </div>
        </div>
      </div>

      {/* Action Panel for Script Code */}
      <div className="p-6 border-b border-rose-100 bg-rose-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-slate-900 flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-rose-500 text-xs font-bold text-white">1</span>
            Código de Google Apps Script
          </h3>
          <p className="text-xs text-slate-600 mt-1">Este código actúa como el puente API entre esta aplicación web y sus hojas de Google Sheets.</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <button
            onClick={handleCopyCode}
            id="copy-script-btn"
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow transition cursor-pointer font-bold"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4 text-green-400" />
                Copiado
              </>
            ) : (
              <>
                <Clipboard className="h-4 w-4" />
                Copiar Código
              </>
            )}
          </button>
          <button
            onClick={handleDownloadCode}
            id="download-script-btn"
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 font-semibold text-xs rounded-xl shadow-sm transition cursor-pointer font-bold"
          >
            <Download className="h-4 w-4" />
            Descargar .js
          </button>
        </div>
      </div>

      {/* Steps Content */}
      <div className="p-6 md:p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Left Column: Steps */}
        <div className="space-y-6">
          <h4 className="text-sm font-semibold text-slate-500 uppercase tracking-widest">Procedimiento paso a paso</h4>
          
          <div className="space-y-4">
            {/* Step 2 */}
            <div className="flex items-start gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-800 border border-slate-200">2</span>
              <div>
                <h5 className="font-bold text-sm text-slate-900">Crear documento de Google Sheets</h5>
                <p className="text-xs text-slate-600 mt-1">
                  Ingrese a su cuenta de Google, cree un archivo de <strong className="text-slate-800 font-bold">Google Sheets</strong> nuevo (o use uno existente) donde quiera conservar sus promedios y reportes.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-start gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-800 border border-slate-200">3</span>
              <div>
                <h5 className="font-bold text-sm text-slate-900">Abrir el editor de Apps Script</h5>
                <p className="text-xs text-slate-600 mt-1">
                  En el menú superior de la hoja de cálculo, vaya a <strong className="text-slate-800 font-bold">Extensiones</strong> &gt; <strong className="text-slate-800 font-bold">Apps Script</strong>. Se abrirá una ventana con un editor de código.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex items-start gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-800 border border-slate-200">4</span>
              <div>
                <h5 className="font-bold text-sm text-slate-900">Pegar y Guardar</h5>
                <p className="text-xs text-slate-600 mt-1">
                  Borre cualquier código existente, <strong className="text-blue-600 font-bold">pegue el código</strong> que acaba de copiar del paso 1, y guarde el proyecto haciendo clic en el icono del <strong className="text-slate-800 font-bold">disquete (Guardar)</strong> o pulsando <kbd className="bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 text-[10px] font-mono shadow-sm">Ctrl + S</kbd>.
                </p>
              </div>
            </div>

            {/* Step 5 */}
            <div className="flex items-start gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-800 border border-slate-200">5</span>
              <div>
                <h5 className="font-bold text-sm text-slate-900">Nueva Implementación</h5>
                <p className="text-xs text-slate-600 mt-1">
                  Haga clic en el botón superior azul <strong className="text-slate-850 font-bold">Nueva implementación</strong> (New Deployment) &gt; Seleccione el tipo de engranaje &gt; <strong className="text-slate-850 font-bold">Aplicación web</strong>.
                </p>
              </div>
            </div>

            {/* Step 6 */}
            <div className="flex items-start gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-100 text-xs font-black text-amber-800 border border-amber-200">6</span>
              <div>
                <h5 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                  Configuración Crucial
                  <span className="px-1.5 py-0.5 bg-amber-100 text-[9px] text-amber-800 font-extrabold rounded uppercase">Requisito</span>
                </h5>
                <div className="text-xs text-slate-600 mt-1 space-y-1 bg-amber-50/50 p-2.5 rounded-lg border border-amber-100">
                  <p>Configure exactamente las siguientes opciones:</p>
                  <ul className="list-disc pl-4 space-y-1 mt-1 text-slate-700">
                    <li><strong>Descripción:</strong> <span className="text-slate-600 font-mono">Api Sincronizacion</span></li>
                    <li><strong>Ejecutar como:</strong> <span className="font-bold text-slate-800">Como yo (your-email@gmail.com)</span></li>
                    <li><strong>Quién tiene acceso:</strong> <span className="font-bold text-rose-700">Cualquiera (Anyone)</span></li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Step 7 */}
            <div className="flex items-start gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-800 border border-slate-200">7</span>
              <div>
                <h5 className="font-bold text-sm text-slate-900">Implementar y Autorizar</h5>
                <p className="text-xs text-slate-600 mt-1">
                  Haga clic en el botón <strong className="text-slate-800 font-bold">Implementar</strong>. Google le solicitará que autorice el acceso. Deberá conceder acceso para que el script pueda escribir en la hoja a su nombre.
                </p>
              </div>
            </div>

            {/* Step 8 */}
            <div className="flex items-start gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs text-slate-800 border border-slate-200">8</span>
              <div>
                <h5 className="font-bold text-sm text-slate-900">Copiar URL y Sincronizar</h5>
                <p className="text-xs text-slate-600 mt-1">
                  Al terminar, copie la <strong className="text-slate-800 font-bold">URL de la aplicación web</strong> que le ofrece la ventana. Péguela arriba en esta web app en el panel de sincronización para enlazar su cuenta.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Info & Benefits */}
        <div className="space-y-6 bg-slate-50 p-6 rounded-2xl border border-slate-100">
          <h4 className="text-sm font-semibold text-slate-800 flex items-center gap-2">
            <FileText className="h-4 w-4 text-blue-600" />
            ¿Cómo funciona esta Sincronización?
          </h4>
          <p className="text-xs text-slate-600 leading-relaxed">
            Al realizar sincronizaciones, esta aplicación compila todo su registro local (nombres de alumnos, asistencias por fecha, notas por parcial) en un paquete compacto JSON y lo transmite de forma segura a su Apps Script de Google.
          </p>

          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-3">
              <div className="h-2 w-2 rounded-full bg-indigo-600"></div>
              <p className="text-xs text-slate-700"><strong className="font-semibold text-slate-900">Centralización Inteligente:</strong> Guarda todo en primer plano de manera que no pierda datos, incluso si cierra la pestaña accidentalmente.</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-2 w-2 rounded-full bg-indigo-600"></div>
              <p className="text-xs text-slate-700"><strong className="font-semibold text-slate-900">Reportes Automáticos:</strong> Crea 5 pestañas legibles automáticamente en su hoja de Google Sheets: 3 por cada Parcial para desglosar promedios, 1 de Asistencia Diaria y 1 Reporte Trimestral consolidado con indicadores de reprobación y promedios generales.</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-2 w-2 rounded-full bg-indigo-600"></div>
              <p className="text-xs text-slate-700"><strong className="font-semibold text-slate-900">Compatibilidad con GitHub Pages:</strong> Dado que almacena todas las configuraciones en <code className="bg-slate-100 text-[11px] px-1 rounded font-mono">localStorage</code> y utiliza fetch directo al Web App implementado, la aplicación puede compilarse y subirse a GitHub Pages directamente de forma 100% gratuita sin requerir servidores.</p>
            </div>
          </div>

          {/* Deployment info */}
          <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl">
            <h5 className="font-bold text-xs text-blue-900 flex items-center gap-1.5">
              <Link className="h-3.5 w-3.5" />
              Preparado para ser Página de GitHub
            </h5>
            <p className="text-[11px] text-blue-800 leading-relaxed mt-1">
              Para subir a GitHub Pages, descargue el proyecto comprimido o súbalo a su repositorio. Esta app está configurada con rutas relativas listas para activarse desde el menú <strong className="font-semibold">Settings &gt; Pages</strong> en su repositorio de GitHub. ¡No requiere base de datos externa aparte de Google Sheets!
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
