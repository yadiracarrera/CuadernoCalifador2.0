import { AcademicColumn, Student, ClassSettings } from '../../src/types';
import { Award, AlertOctagon, Users, Calendar, Percent, BookOpen } from 'lucide-react';

interface DashboardProps {
  students: Student[];
  columns: AcademicColumn[];
  settings: ClassSettings;
  attendanceDates: string[];
}

export default function Dashboard({ students, columns, settings, attendanceDates }: DashboardProps) {
  if (students.length === 0) {
    return (
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-12 text-center text-slate-500">
        <Users className="h-12 w-12 text-slate-400 mx-auto mb-4 stroke-1" />
        <h3 className="font-bold text-slate-800 text-lg">No hay datos suficientes para análisis</h3>
        <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">Añada alumnos y calificaciones en las pestañas correspondientes para visualizar el rendimiento grupal.</p>
      </div>
    );
  }

  // Calculate detailed students statistics
  const calculatedStudents = students.map(student => {
    const parcialAverages = [1, 2, 3].map(p => {
      const pCols = columns.filter(c => c.parcial === p);
      const acts = pCols.filter(c => c.type === 'actividad');
      const evs = pCols.filter(c => c.type === 'evaluacion');
      
      let actSum = 0, actCount = 0;
      acts.forEach(col => {
        const score = student.grades[col.id] !== undefined ? student.grades[col.id] : 0;
        actSum += col.maxScore > 0 ? (score / col.maxScore) * settings.gradingScale : 0;
        actCount++;
      });
      const actAvg = actCount > 0 ? actSum / actCount : 0;
      
      let evalSum = 0, evalCount = 0;
      evs.forEach(col => {
        const score = student.grades[col.id] !== undefined ? student.grades[col.id] : 0;
        evalSum += col.maxScore > 0 ? (score / col.maxScore) * settings.gradingScale : 0;
        evalCount++;
      });
      const evalAvg = evalCount > 0 ? evalSum / evalCount : 0;
      
      if (actCount > 0 && evalCount > 0) {
        return (actAvg * (settings.weightActividades / 100)) + (evalAvg * (settings.weightEvaluaciones / 100));
      } else if (actCount > 0) {
        return actAvg;
      } else if (evalCount > 0) {
        return evalAvg;
      }
      return 0;
    });
    
    const finalTrimestre = (parcialAverages[0] + parcialAverages[1] + parcialAverages[2]) / 3;
    
    // Attendance
    let pCount = 0, aCount = 0, rCount = 0;
    attendanceDates.forEach(d => {
      const status = student.attendance[d];
      if (status === 'P') pCount++;
      else if (status === 'A') aCount++;
      else if (status === 'R') rCount++;
    });
    const activeDays = pCount + aCount + rCount;
    const attendanceRate = activeDays > 0 ? ((pCount + (rCount * 0.5)) / activeDays) * 100 : 0;
    
    return {
      ...student,
      parcialAverages,
      finalTrimestre,
      attendanceRate
    };
  });

  // KPI calculations
  const totalStudents = calculatedStudents.length;
  
  const classAverage = calculatedStudents.reduce((acc, s) => acc + s.finalTrimestre, 0) / totalStudents;
  
  const classAttendanceAverage = calculatedStudents.reduce((acc, s) => acc + s.attendanceRate, 0) / totalStudents;
  
  const maxPassingGrade = settings.gradingScale === 10 ? 6.0 : 60;
  const passingCount = calculatedStudents.filter(s => s.finalTrimestre >= maxPassingGrade).length;
  const passingRate = (passingCount / totalStudents) * 100;

  // Best student
  const sortedByGrade = [...calculatedStudents].sort((a, b) => b.finalTrimestre - a.finalTrimestre);
  const bestStudent = sortedByGrade[0];
  const lowestStudent = sortedByGrade[sortedByGrade.length - 1];

  // Best attendance
  const sortedByAttendance = [...calculatedStudents].sort((a, b) => b.attendanceRate - a.attendanceRate);
  const bestAttendanceStudent = sortedByAttendance[0];

  return (
    <div className="space-y-8">
      
      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        {/* Metric Item 1 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Matrícula Escolar</span>
            <div className="text-3xl font-extrabold text-slate-900 mt-1">{totalStudents}</div>
            <p className="text-xs text-slate-500 mt-1">Alumnos activos inscritos</p>
          </div>
          <div className="bg-slate-100 p-3.5 rounded-2xl text-slate-800">
            <Users className="h-6 w-6" />
          </div>
        </div>

        {/* Metric Item 2 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Promedio Escolar</span>
            <div className="text-3xl font-extrabold text-blue-600 mt-1 font-mono">{classAverage.toFixed(2)}</div>
            <p className="text-xs text-slate-500 mt-1">Escala en base {settings.gradingScale}</p>
          </div>
          <div className="bg-blue-50 p-3.5 rounded-2xl text-blue-600">
            <BookOpen className="h-6 w-6" />
          </div>
        </div>

        {/* Metric Item 3 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Asistencia Promedio</span>
            <div className="text-3xl font-extrabold text-emerald-600 mt-1 font-mono">{classAttendanceAverage.toFixed(1)}%</div>
            <p className="text-xs text-slate-500 mt-1">De {attendanceDates.length} fechas registradas</p>
          </div>
          <div className="bg-emerald-50 p-3.5 rounded-2xl text-emerald-600">
            <Calendar className="h-6 w-6" />
          </div>
        </div>

        {/* Metric Item 4 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Índice de Aprobación</span>
            <div className="text-3xl font-extrabold text-violet-600 mt-1 font-mono">{passingRate.toFixed(1)}%</div>
            <p className="text-xs text-slate-500 mt-1">{passingCount} de {totalStudents} alumnos con &ge; {maxPassingGrade}</p>
          </div>
          <div className="bg-violet-50 p-3.5 rounded-2xl text-violet-600">
            <Percent className="h-6 w-6" />
          </div>
        </div>

      </div>

      {/* High / Low Performers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Card 1: Alumno Destacado */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between">
          <div className="p-6">
            <div className="flex items-center gap-3">
              <div className="bg-amber-100 p-2 text-amber-600 rounded-xl">
                <Award className="h-5 w-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">Mayor Promedio Escolar</h4>
            </div>
            
            <div className="mt-5">
              <div className="text-xl font-black text-slate-900 leading-tight">{bestStudent?.name || "N/A"}</div>
              <p className="text-xs text-slate-500 mt-1">Desempeño general de excelencia académica.</p>
            </div>
          </div>
          
          <div className="bg-amber-50/50 px-6 py-4 border-t border-amber-100 flex justify-between items-center">
            <span className="text-xs font-semibold text-amber-800">Cómputo final:</span>
            <span className="text-lg font-black font-mono text-amber-900">{bestStudent ? bestStudent.finalTrimestre.toFixed(2) : '0.00'}</span>
          </div>
        </div>

        {/* Card 2: Alumno con mayor asistencia */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between">
          <div className="p-6">
            <div className="flex items-center gap-3">
              <div className="bg-sky-100 p-2 text-sky-600 rounded-xl">
                <Calendar className="h-5 w-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">Mayor Asistencia Diaria</h4>
            </div>
            
            <div className="mt-5">
              <div className="text-xl font-black text-slate-900 leading-tight">{bestAttendanceStudent?.name || "N/A"}</div>
              <p className="text-xs text-slate-500 mt-1">Constancia y permanencia áulica perfecta.</p>
            </div>
          </div>
          
          <div className="bg-sky-50/50 px-6 py-4 border-t border-sky-100 flex justify-between items-center">
            <span className="text-xs font-semibold text-sky-800">Porcentaje total:</span>
            <span className="text-lg font-black font-mono text-sky-900">{bestAttendanceStudent ? bestAttendanceStudent.attendanceRate.toFixed(1) + '%' : '0.0%'}</span>
          </div>
        </div>

        {/* Card 3: Alumno en Riesgo Académico */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between md:col-span-2 lg:col-span-1">
          <div className="p-6">
            <div className="flex items-center gap-3">
              <div className="bg-red-100 p-2 text-red-600 rounded-xl">
                <AlertOctagon className="h-5 w-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">Sugerencia de Tutoría / Apoyo</h4>
            </div>
            
            <div className="mt-5">
              <div className="text-xl font-black text-slate-900 leading-tight">
                {lowestStudent && lowestStudent.finalTrimestre < maxPassingGrade ? lowestStudent.name : "Ninguno en riesgo"}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {lowestStudent && lowestStudent.finalTrimestre < maxPassingGrade 
                  ? "Requiere asesoría académica urgente y plan de recuperación."
                  : "Todos los alumnos están con un promedio aprobatorio y estable."}
              </p>
            </div>
          </div>
          
          <div className="bg-red-50/50 px-6 py-4 border-t border-red-100 flex justify-between items-center">
            <span className="text-xs font-semibold text-red-800">Promedio menor:</span>
            <span className="text-lg font-black font-mono text-red-900">
              {lowestStudent && lowestStudent.finalTrimestre < maxPassingGrade ? lowestStudent.finalTrimestre.toFixed(2) : '-'}
            </span>
          </div>
        </div>

      </div>

      {/* Visual Standings / Progress Bars of all Students */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <h4 className="font-bold text-slate-900 text-base">Tabla de Escalamiento Académico y Presencial</h4>
          <p className="text-xs text-slate-500 mt-1">Comparativa visual clara del promedio final frente a su participación de asistencia diaria.</p>
        </div>
        
        <div className="p-6 space-y-6">
          {calculatedStudents.map(student => {
            const isPassing = student.finalTrimestre >= maxPassingGrade;
            // Calculating standard percentages for progress meter
            const gradePercent = (student.finalTrimestre / settings.gradingScale) * 100;
            return (
              <div key={student.id} className="grid grid-cols-1 md:grid-cols-4 items-center gap-4 py-1.5 border-b border-slate-100 last:border-0">
                <div className="md:col-span-1">
                  <div className="font-extrabold text-slate-950 text-sm">{student.name}</div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5 uppercase tracking-wide">ID: {student.id.substring(0, 8)}...</div>
                </div>
                
                {/* Grade Progress Meter */}
                <div className="md:col-span-2 space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Promedio: <strong className="font-mono text-slate-800">{student.finalTrimestre.toFixed(2)}</strong></span>
                    <span className={`font-semibold ${isPassing ? 'text-green-600' : 'text-rose-600'}`}>{isPassing ? 'Aprobado' : 'Reprobado'}</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${isPassing ? 'bg-blue-600' : 'bg-rose-500'}`} 
                      style={{ width: `${Math.min(100, gradePercent)}%` }}
                    />
                  </div>
                </div>

                {/* Attendance Progress Meter */}
                <div className="md:col-span-1 space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-500">Asistencia: <strong className="font-mono text-slate-800">{student.attendanceRate.toFixed(1)}%</strong></span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${student.attendanceRate >= 80 ? 'bg-emerald-500' : student.attendanceRate >= 60 ? 'bg-amber-500' : 'bg-rose-500'}`} 
                      style={{ width: `${student.attendanceRate}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
