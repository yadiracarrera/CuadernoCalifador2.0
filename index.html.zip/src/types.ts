export interface AcademicColumn {
  id: string;
  name: string;
  type: 'evaluacion' | 'actividad';
  parcial: 1 | 2 | 3;
  maxScore: number;
}

export type AttendanceStatus = 'P' | 'A' | 'R' | 'J'; // Presente, Ausente, Retardo, Justificado

export interface Student {
  id: string;
  name: string;
  grades: {
    [columnId: string]: number; // score for academic columns
  };
  attendance: {
    [dateStr: string]: AttendanceStatus; // status for each attendance date
  };
}

export interface SyncConfig {
  appsScriptUrl: string;
  lastSync: string | null;
  status: 'disconnected' | 'syncing' | 'connected' | 'error';
  errorMessage?: string;
}

export interface ClassSettings {
  gradingScale: 10 | 100;
  weightEvaluaciones: number; // e.g., 60 for 60%
  weightActividades: number;  // e.g., 40 for 40%
}
