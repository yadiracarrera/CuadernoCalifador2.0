export const APPS_SCRIPT_CODE = `/**
 * Google Apps Script - Sistema de Control y Evaluación Escolar
 * Copie este código completo en Extensiones > Apps Script de su Google Sheet
 * Asegúrese de Implementar como "Aplicación web" con acceso para "Cualquiera" (Anyone)
 */

function doGet(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet();
  let dbSheet = sheet.getSheetByName("BD_SISTEMA");
  
  // Si no existe la hoja de base de datos, retornar vacío
  if (!dbSheet) {
    return ContentService.createTextOutput(JSON.stringify({ 
      success: true, 
      message: "No hay datos iniciados", 
      data: null 
    }))
    .setMimeType(ContentService.MimeType.JSON)
    .setHeaders({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST'
    });
  }
  
  const jsonStr = dbSheet.getRange(1, 1).getValue();
  let stateData = null;
  try {
    if (jsonStr) {
      stateData = JSON.parse(jsonStr);
    }
  } catch (err) {
    // Error al parsear
  }
  
  return ContentService.createTextOutput(JSON.stringify({
    success: true,
    data: stateData
  }))
  .setMimeType(ContentService.MimeType.JSON)
  .setHeaders({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST'
  });
}

function doPost(e) {
  try {
    const postData = JSON.parse(e.postData.contents);
    const sheet = SpreadsheetApp.getActiveSpreadsheet();
    
    // 1. Guardar estado completo como JSON para sincronización bidireccional perfecta
    let dbSheet = sheet.getSheetByName("BD_SISTEMA");
    if (!dbSheet) {
      dbSheet = sheet.insertSheet("BD_SISTEMA");
      dbSheet.hideSheet(); // Ocultar para no molestar la vista humana
    }
    dbSheet.getRange(1, 1).setValue(JSON.stringify(postData));
    
    // 2. Generar reportes y hojas humanas legibles automáticamente
    actualizarHojasCalificaciones(sheet, postData);
    actualizarHojaAsistencia(sheet, postData);
    generarReporteMensualResumen(sheet, postData);
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      message: "Sincronización y reportes generados exitosamente!"
    }))
    .setMimeType(ContentService.MimeType.JSON)
    .setHeaders({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST'
    });
    
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      error: error.toString()
    }))
    .setMimeType(ContentService.MimeType.JSON)
    .setHeaders({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST'
    });
  }
}

// Genera o actualiza las pestañas de Calificaciones por cada Parcial (P1, P2, P3)
function actualizarHojasCalificaciones(sheet, data) {
  const students = data.students || [];
  const columns = data.columns || [];
  const settings = data.settings || { gradingScale: 10, weightEvaluaciones: 50, weightActividades: 50 };
  
  for (let p = 1; p <= 3; p++) {
    const sheetName = "Parcial " + p;
    let pSheet = sheet.getSheetByName(sheetName);
    if (!pSheet) {
      pSheet = sheet.insertSheet(sheetName);
    } else {
      pSheet.clear();
    }
    
    // Filtrar columnas de este parcial
    const pCols = columns.filter(c => c.parcial === p);
    const actCols = pCols.filter(c => c.type === 'actividad');
    const evalCols = pCols.filter(c => c.type === 'evaluacion');
    
    // Preparar encabezados
    const headers = ["ID Alumno", "Nombre Estudiante"];
    actCols.forEach(c => headers.push(c.name + " (Act - Máx " + c.maxScore + ")"));
    headers.push("Promedio Actividades (" + settings.weightActividades + "%)");
    
    evalCols.forEach(c => headers.push(c.name + " (Ev - Máx " + c.maxScore + ")"));
    headers.push("Promedio Evaluaciones (" + settings.weightEvaluaciones + "%)");
    headers.push("PROMEDIO PARCIAL");
    
    pSheet.appendRow(headers);
    
    // Llenar datos de estudiantes
    students.forEach(student => {
      const row = [student.id, student.name];
      
      // Calificaciones actividades
      let actSum = 0;
      let actCount = 0;
      actCols.forEach(col => {
        const score = student.grades[col.id] !== undefined ? student.grades[col.id] : 0;
        // Normalizar a escala de base 10 o 100 para promedios
        const normalized = col.maxScore > 0 ? (score / col.maxScore) * settings.gradingScale : 0;
        row.push(score);
        actSum += normalized;
        actCount++;
      });
      const actAvg = actCount > 0 ? actSum / actCount : 0;
      row.push(Number(actAvg.toFixed(2)));
      
      // Calificaciones evaluaciones
      let evalSum = 0;
      let evalCount = 0;
      evalCols.forEach(col => {
        const score = student.grades[col.id] !== undefined ? student.grades[col.id] : 0;
        const normalized = col.maxScore > 0 ? (score / col.maxScore) * settings.gradingScale : 0;
        row.push(score);
        evalSum += normalized;
        evalCount++;
      });
      const evalAvg = evalCount > 0 ? evalSum / evalCount : 0;
      row.push(Number(evalAvg.toFixed(2)));
      
      // Promedio parcial ponderado
      let partialGrade = 0;
      if (actCount > 0 && evalCount > 0) {
        partialGrade = (actAvg * (settings.weightActividades / 100)) + (evalAvg * (settings.weightEvaluaciones / 100));
      } else if (actCount > 0) {
        partialGrade = actAvg;
      } else if (evalCount > 0) {
        partialGrade = evalAvg;
      }
      row.push(Number(partialGrade.toFixed(2)));
      
      pSheet.appendRow(row);
    });
    
    // Dar formato estético
    darFormatoBonito(pSheet, headers.length, students.length);
  }
}

// Genera hoja legible de asistencias diarias
function actualizarHojaAsistencia(sheet, data) {
  const students = data.students || [];
  const attendanceDates = data.attendanceDates || [];
  
  const sheetName = "Asistencia Diaria";
  let astSheet = sheet.getSheetByName(sheetName);
  if (!astSheet) {
    astSheet = sheet.insertSheet(sheetName);
  } else {
    astSheet.clear();
  }
  
  // Encabezados
  const headers = ["ID Alumno", "Nombre Estudiante"];
  attendanceDates.forEach(d => headers.push(d));
  headers.push("Presentes (P)");
  headers.push("Ausentes (A)");
  headers.push("Retardos (R)");
  headers.push("Justificados (J)");
  headers.push("% Asistencia");
  
  astSheet.appendRow(headers);
  
  // Datos
  students.forEach(student => {
    const row = [student.id, student.name];
    let pCount = 0, aCount = 0, rCount = 0, jCount = 0;
    
    attendanceDates.forEach(dateStr => {
      const status = student.attendance[dateStr] || 'A';
      row.push(status);
      if (status === 'P') pCount++;
      else if (status === 'A') aCount++;
      else if (status === 'R') rCount++;
      else if (status === 'J') jCount++;
    });
    
    row.push(pCount);
    row.push(aCount);
    row.push(rCount);
    row.push(jCount);
    
    const activeDays = pCount + aCount + rCount;
    const rate = activeDays > 0 ? ((pCount + (rCount * 0.5)) / activeDays) * 100 : 0;
    row.push(rate.toFixed(1) + "%");
    
    astSheet.appendRow(row);
  });
  
  darFormatoBonito(astSheet, headers.length, students.length);
}

// Genera reporte de resumen trimestral y estadísticas
function generarReporteMensualResumen(sheet, data) {
  const students = data.students || [];
  const columns = data.columns || [];
  const settings = data.settings || { gradingScale: 10, weightEvaluaciones: 50, weightActividades: 50 };
  const attendanceDates = data.attendanceDates || [];
  
  const sheetName = "Resumen Trimestral";
  let repSheet = sheet.getSheetByName(sheetName);
  if (!repSheet) {
    repSheet = sheet.insertSheet(sheetName);
  } else {
    repSheet.clear();
  }
  
  // Título elegante del reporte
  repSheet.getRange("A1").setValue("REPORTE DE RENDIMIENTO TRIMESTRAL").setFontSize(16).setFontWeight("bold").setFontColor("#1e293b");
  repSheet.getRange("A2").setValue("Fecha de reporte: " + Utilities.formatDate(new Date(), "GMT-6", "dd/MM/yyyy HH:mm")).setFontStyle("italic").setFontColor("#64748b");
  
  const headers = ["ID Alumno", "Nombre Estudiante", "Promedio P1", "Promedio P2", "Promedio P3", "PROMEDIO TRIMESTRE", "% Asistencia General", "Estado"];
  repSheet.getRange(4, 1, 1, headers.length).setValues([headers]);
  
  let totalClassGradeSum = 0;
  let studentsCount = 0;
  
  students.forEach((student, index) => {
    const rowNum = index + 5;
    const row = [student.id, student.name];
    
    // Calcular promedios parciales
    const pAvg = [1, 2, 3].map(p => {
      const pCols = columns.filter(c => c.parcial === p);
      const acts = pCols.filter(c => c.type === 'actividad');
      const evs = pCols.filter(c => c.type === 'evaluacion');
      
      let actSum = 0, actCount = 0;
      acts.forEach(col => {
        const score = student.grades[col.id] !== undefined ? student.grades[col.id] : 0;
        actSum += col.maxScore > 0 ? (score / col.maxScore) * settings.gradingScale : 0;
        actCount++;
      });
      const actAvg = actCount > 0 ? actSum / actCount : 0;
      
      let evalSum = 0, evalCount = 0;
      evs.forEach(col => {
        const score = student.grades[col.id] !== undefined ? student.grades[col.id] : 0;
        evalSum += col.maxScore > 0 ? (score / col.maxScore) * settings.gradingScale : 0;
        evalCount++;
      });
      const evalAvg = evalCount > 0 ? evalSum / evalCount : 0;
      
      if (actCount > 0 && evalCount > 0) {
        return (actAvg * (settings.weightActividades / 100)) + (evalAvg * (settings.weightEvaluaciones / 100));
      } else if (actCount > 0) {
        return actAvg;
      } else if (evalCount > 0) {
        return evalAvg;
      }
      return 0; // Sin columnas
    });
    
    row.push(Number(pAvg[0].toFixed(2)));
    row.push(Number(pAvg[1].toFixed(2)));
    row.push(Number(pAvg[2].toFixed(2)));
    
    // Promedio final trimestre (media de los 3 parciales)
    const finalTrimestre = (pAvg[0] + pAvg[1] + pAvg[2]) / 3;
    row.push(Number(finalTrimestre.toFixed(2)));
    
    totalClassGradeSum += finalTrimestre;
    studentsCount++;
    
    // % Asistencia
    let pCount = 0, aCount = 0, rCount = 0;
    attendanceDates.forEach(dateStr => {
      const status = student.attendance[dateStr] || 'A';
      if (status === 'P') pCount++;
      else if (status === 'A') aCount++;
      else if (status === 'R') rCount++;
    });
    const activeDays = pCount + aCount + rCount;
    const rate = activeDays > 0 ? ((pCount + (rCount * 0.5)) / activeDays) : 0;
    row.push(Number((rate * 100).toFixed(1)));
    
    // Estado (Aprobado / Reprobado)
    const passingGrade = settings.gradingScale === 10 ? 6.0 : 60;
    const statusText = finalTrimestre >= passingGrade ? "APROBADO" : "REPROBADO";
    row.push(statusText);
    
    repSheet.getRange(rowNum, 1, 1, row.length).setValues([row]);
    
    // Formato de estado color
    const cellEstado = repSheet.getRange(rowNum, 8);
    if (statusText === "APROBADO") {
      cellEstado.setBackground("#dcfce7").setFontColor("#166534").setFontWeight("bold");
    } else {
      cellEstado.setBackground("#fee2e2").setFontColor("#991b1b").setFontWeight("bold");
    }
  });
  
  // Agregar promedio general de la clase abajo
  if (studentsCount > 0) {
    const totalRowIndex = students.length + 6;
    repSheet.getRange(totalRowIndex, 2).setValue("PROMEDIO GRUPAL").setFontWeight("bold");
    const classAvg = totalClassGradeSum / studentsCount;
    repSheet.getRange(totalRowIndex, 6).setValue(Number(classAvg.toFixed(2))).setFontWeight("bold").setFontColor("#1d4ed8");
  }
  
  // Dar formato
  darFormatoBonito(repSheet, headers.length, students.length, 4);
}

// Helper para dar formato estético profesional a cualquier pestaña
function darFormatoBonito(sheet, totalCols, numRows, headerRowIndex) {
  const startRow = headerRowIndex || 1;
  const numRowsFormato = numRows + 1; // Encabezado + Filas
  
  const rangeTotal = sheet.getRange(startRow, 1, numRowsFormato, totalCols);
  
  // Bordes sutiles y alineación central en datos
  rangeTotal.setBorder(true, true, true, true, true, true, "#e2e8f0", SpreadsheetApp.BorderStyle.SOLID);
  rangeTotal.setHorizontalAlignment("center");
  
  // Alinear nombres de alumnos a la izquierda para mejor lectura
  sheet.getRange(startRow + 1, 2, numRows, 1).setHorizontalAlignment("left");
  
  // Encabezado principal
  const rangeHeader = sheet.getRange(startRow, 1, 1, totalCols);
  rangeHeader.setBackground("#1e293b");
  rangeHeader.setFontColor("#f8fafc");
  rangeHeader.setFontWeight("bold");
  rangeHeader.setFontSize(10);
  
  // Ajustar ancho de columnas automáticamente
  for (let c = 1; c <= totalCols; c++) {
    sheet.autoResizeColumn(c);
    const colWidth = sheet.getColumnWidth(c);
    if (colWidth < 80) sheet.setColumnWidth(c, 80);
    else if (c === 2) sheet.setColumnWidth(c, 240); // Columna de nombre más ancha
  }
}
`;
