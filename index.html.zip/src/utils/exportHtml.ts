import { AcademicColumn, Student, ClassSettings } from '../../src/types';

export function exportHtmlReport(
  students: Student[],
  columns: AcademicColumn[],
  settings: ClassSettings,
  attendanceDates: string[]
): string {
  // Calculate general statistics for the HTML report
  const activeStudentsCount = students.length;
  
  // Calculations helper for final grades and attendance
  const calculatedStudents = students.map(student => {
    const parcialAverages = [1, 2, 3].map(p => {
      const pCols = columns.filter(c => c.parcial === p);
      const acts = pCols.filter(c => c.type === 'actividad');
      const evs = pCols.filter(c => c.type === 'evaluacion');
      
      let actSum = 0, actCount = 0;
      acts.forEach(col => {
        const score = student.grades[col.id] !== undefined ? student.grades[col.id] : 0;
        actSum += col.maxScore > 0 ? (score / col.maxScore) * settings.gradingScale : 0;
        actCount++;
      });
      const actAvg = actCount > 0 ? actSum / actCount : 0;
      
      let evalSum = 0, evalCount = 0;
      evs.forEach(col => {
        const score = student.grades[col.id] !== undefined ? student.grades[col.id] : 0;
        evalSum += col.maxScore > 0 ? (score / col.maxScore) * settings.gradingScale : 0;
        evalCount++;
      });
      const evalAvg = evalCount > 0 ? evalSum / evalCount : 0;
      
      if (actCount > 0 && evalCount > 0) {
        return (actAvg * (settings.weightActividades / 100)) + (evalAvg * (settings.weightEvaluaciones / 100));
      } else if (actCount > 0) {
        return actAvg;
      } else if (evalCount > 0) {
        return evalAvg;
      }
      return 0;
    });
    
    const finalTrimestre = (parcialAverages[0] + parcialAverages[1] + parcialAverages[2]) / 3;
    
    // Attendance
    let pCount = 0, aCount = 0, rCount = 0, jCount = 0;
    attendanceDates.forEach(d => {
      const status = student.attendance[d];
      if (status === 'P') pCount++;
      else if (status === 'A') aCount++;
      else if (status === 'R') rCount++;
      else if (status === 'J') jCount++;
    });
    const activeDays = pCount + aCount + rCount;
    const attendanceRate = activeDays > 0 ? ((pCount + (rCount * 0.5)) / activeDays) * 100 : 0;
    
    return {
      ...student,
      parcialAverages,
      finalTrimestre,
      attendanceRate,
      pCount,
      aCount,
      rCount,
      jCount
    };
  });
  
  const classAverage = calculatedStudents.length > 0 
    ? calculatedStudents.reduce((acc, st) => acc + st.finalTrimestre, 0) / calculatedStudents.length
    : 0;
    
  const classAttendanceAverage = calculatedStudents.length > 0
    ? calculatedStudents.reduce((acc, st) => acc + st.attendanceRate, 0) / calculatedStudents.length
    : 0;
    
  // Dynamic student rows for index table in HTML
  const tableRows = calculatedStudents.map((st, idx) => {
    const isPassing = st.finalTrimestre >= (settings.gradingScale === 10 ? 6.0 : 60);
    const badgeBg = isPassing ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
    return `
      <tr class="hover:bg-gray-50 transition border-b border-gray-100">
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">${idx + 1}</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">${st.name}</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700 font-mono">${st.parcialAverages[0].toFixed(2)}</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700 font-mono">${st.parcialAverages[1].toFixed(2)}</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700 font-mono">${st.parcialAverages[2].toFixed(2)}</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-blue-600 font-mono">${st.finalTrimestre.toFixed(2)}</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-700 font-mono">${st.attendanceRate.toFixed(1)}%</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-right">
          <span class="px-3 py-1 rounded-full text-xs font-bold ${badgeBg}">${isPassing ? 'APROBADO' : 'REPROBADO'}</span>
        </td>
      </tr>
    `;
  }).join('');

  // Dynamic student detail cards
  const studentCards = calculatedStudents.map(st => {
    const isPassing = st.finalTrimestre >= (settings.gradingScale === 10 ? 6.0 : 60);
    const borderAccent = isPassing ? 'border-l-green-500' : 'border-l-red-500';
    
    // Parcial structures
    const parciDetail = [1, 2, 3].map(p => {
      const pCols = columns.filter(c => c.parcial === p);
      const colsHtml = pCols.map(col => {
        const val = st.grades[col.id] !== undefined ? st.grades[col.id] : '-';
        return `
          <div class="flex justify-between items-center py-1.5 border-b border-gray-100 text-xs">
            <span class="text-gray-500 font-medium">${col.name} <em class="text-[10px] text-gray-400">(${col.type === 'evaluacion' ? 'Ev' : 'Act'})</em></span>
            <span class="font-semibold text-gray-800 font-mono">${val}/${col.maxScore}</span>
          </div>
        `;
      }).join('') || '<div class="text-xs text-gray-400 italic py-2 text-center">Sin actividades o evaluaciones registradas</div>';
      
      return `
        <div class="bg-gray-50 p-3 rounded-lg border border-gray-100">
          <div class="flex justify-between items-center border-b border-gray-200 pb-1.5 mb-2">
            <h4 class="text-xs font-bold text-gray-700 uppercase">Parcial ${p}</h4>
            <span class="text-xs font-black text-gray-900 font-mono">${st.parcialAverages[p-1].toFixed(2)}</span>
          </div>
          <div class="space-y-1">
            ${colsHtml}
          </div>
        </div>
      `;
    }).join('');

    return `
      <div class="bg-white rounded-xl shadow-sm border border-gray-200 border-l-4 ${borderAccent} p-6 flex flex-col justify-between">
        <div>
          <div class="flex justify-between items-start mb-4">
            <div>
              <h3 class="text-lg font-extrabold text-gray-900">${st.name}</h3>
              <p class="text-xs text-gray-500 font-mono">ID: ${st.id.substring(0, 8)}...</p>
            </div>
            <div class="text-right">
              <span class="text-2xl font-black text-blue-600 font-mono">${st.finalTrimestre.toFixed(2)}</span>
              <p class="text-[10px] text-gray-400 uppercase font-bold">Promedio Final</p>
            </div>
          </div>
          
          <!-- Attendance Quick Summary -->
          <div class="grid grid-cols-4 gap-1 text-center py-2 px-1 bg-sky-50 rounded-lg text-xs font-mono font-medium text-slate-700 mb-4">
            <div>
              <div class="text-sky-800 font-bold">${st.pCount}</div>
              <div class="text-[9px] text-sky-600 uppercase">Pres</div>
            </div>
            <div>
              <div class="text-amber-800 font-bold">${st.rCount}</div>
              <div class="text-[9px] text-amber-600 uppercase">Ret</div>
            </div>
            <div>
              <div class="text-red-800 font-bold">${st.aCount}</div>
              <div class="text-[9px] text-red-600 uppercase">Aus</div>
            </div>
            <div>
              <div class="text-violet-800 font-bold">${st.jCount}</div>
              <div class="text-[9px] text-violet-600 uppercase">Just</div>
            </div>
          </div>

          <div class="space-y-4">
            ${parciDetail}
          </div>
        </div>

        <div class="mt-6 pt-4 border-t border-gray-100 flex justify-between items-center">
          <span class="text-xs font-semibold text-gray-600">Asistencia: <span class="font-mono text-gray-900 font-bold">${st.attendanceRate.toFixed(1)}%</span></span>
          <span class="px-2.5 py-1.5 rounded-full text-xs font-black uppercase ${isPassing ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
            ${isPassing ? 'APROBADO' : 'REPROBADO'}
          </span>
        </div>
      </div>
    `;
  }).join('');

  // Main Report Rendered as static HTML
  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reporte de Evaluación - Alumnos y Asistencia</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
    body {
      font-family: 'Inter', sans-serif;
    }
    @media print {
      .no-print {
        display: none !important;
      }
      .page-break {
        page-break-before: always;
      }
    }
  </style>
</head>
<body class="bg-slate-50 text-slate-900 selection:bg-blue-100">

  <!-- Header Banner -->
  <header class="bg-gradient-to-r from-slate-900 to-slate-800 text-white shadow-lg py-10 px-6 sm:px-12">
    <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
      <div>
        <span class="bg-blue-600 text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-1 rounded">REPORTE OFICIAL</span>
        <h1 class="text-3xl font-extrabold tracking-tight mt-2">Control de Evaluación y Asistencia</h1>
        <p class="text-slate-300 text-sm mt-1">Reporte trimestral generado automáticamente desde la plataforma de control escolar.</p>
      </div>
      <div class="flex gap-3 no-print">
        <button onclick="window.print()" class="bg-white hover:bg-slate-100 text-slate-900 font-bold py-2.5 px-5 rounded-lg text-sm shadow transition flex items-center gap-2 cursor-pointer">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-3a2 2 0 00-2-2H9a2 2 0 00-2 2v3a2 2 0 002 2zm0 0v-9a2 2 0 012-2h2a2 2 0 012 2v9m-4 0h4" /></svg>
          Imprimir Reporte
        </button>
      </div>
    </div>
  </header>

  <!-- Main Container -->
  <main class="max-w-7xl mx-auto px-6 sm:px-12 py-10">
    
    <!-- KPI Section -->
    <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
      <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <h3 class="text-xs font-bold text-slate-500 uppercase tracking-widest">Alumnos Evaluados</h3>
        <p class="text-4xl font-extrabold text-slate-900 mt-2">${activeStudentsCount}</p>
        <span class="text-xs text-green-600 font-semibold mt-1 inline-block">Matrícula Activa 100%</span>
      </div>
      <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <h3 class="text-xs font-bold text-slate-500 uppercase tracking-widest">Promedio General</h3>
        <p class="text-4xl font-extrabold text-blue-600 mt-2 font-mono">${classAverage.toFixed(2)}</p>
        <span class="text-xs text-slate-500 mt-1 inline-block">Sobre escala base ${settings.gradingScale}</span>
      </div>
      <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <h3 class="text-xs font-bold text-slate-500 uppercase tracking-widest">Asistencia Promedio</h3>
        <p class="text-4xl font-extrabold text-emerald-600 mt-2 font-mono">${classAttendanceAverage.toFixed(1)}%</p>
        <span class="text-xs text-slate-500 mt-1 inline-block">De ${attendanceDates.length} fechas registradas</span>
      </div>
      <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <h3 class="text-xs font-bold text-slate-500 uppercase tracking-widest">Porcentajes de Ponderación</h3>
        <p class="text-lg font-bold text-slate-900 mt-3 flex justify-between">
          <span class="text-gray-500 text-xs">Exámenes / Ev:</span>
          <span>${settings.weightEvaluaciones}%</span>
        </p>
        <p class="text-lg font-bold text-slate-900 mt-1 flex justify-between">
          <span class="text-gray-500 text-xs">Actividades:</span>
          <span>${settings.weightActividades}%</span>
        </p>
      </div>
    </section>

    <!-- Table Section -->
    <section class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-12">
      <div class="px-6 py-5 border-b border-slate-100">
        <h2 class="text-lg font-extrabold text-slate-900">Listado General e Índices de Desempeño</h2>
        <p class="text-xs text-slate-500">Resumen y estatus de cada alumno por parcial y trimestre completo.</p>
      </div>
      <div class="overflow-x-auto">
        <table class="w-full min-w-max">
          <thead class="bg-slate-50 text-slate-500 uppercase text-xs font-bold tracking-wider">
            <tr>
              <th class="px-6 py-3.5 text-left font-mono">#</th>
              <th class="px-6 py-3.5 text-left">Alumno</th>
              <th class="px-6 py-3.5 text-left">Parcial 1</th>
              <th class="px-6 py-3.5 text-left">Parcial 2</th>
              <th class="px-6 py-3.5 text-left">Parcial 3</th>
              <th class="px-6 py-3.5 text-left text-blue-600">Trimestre</th>
              <th class="px-6 py-3.5 text-left">% Asist</th>
              <th class="px-6 py-3.5 text-right">Estatus</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100">
            ${tableRows || '<tr><td colspan="8" class="text-center py-8 text-sm italic text-slate-400">No hay estudiantes cargados en el sistema</td></tr>'}
          </tbody>
        </table>
      </div>
    </section>

    <!-- Detailed Students Breakdown Section -->
    <section class="page-break">
      <div class="mb-6 flex justify-between items-end">
        <div>
          <h2 class="text-2xl font-extrabold tracking-tight text-slate-950">Fichas de Evaluación Individuales</h2>
          <p class="text-sm text-slate-500 mt-0.5">Detalle exhaustivo de calificaciones de actividades y exámenes por estudiante.</p>
        </div>
        <span class="no-print text-xs text-blue-600 font-bold hidden sm:inline">Desglose 1 trimestre completo</span>
      </div>
      
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        ${studentCards || '<div class="col-span-2 text-center py-12 text-sm italic text-slate-400">No hay alumnos para mostrar fichas individuales.</div>'}
      </div>
    </section>

    <!-- Signatures placeholder for printed validity -->
    <section class="mt-20 pt-10 border-t-2 border-dashed border-slate-300 grid grid-cols-1 sm:grid-cols-2 gap-12 text-center text-xs text-slate-500">
      <div>
        <div class="w-48 border-b border-slate-400 mx-auto mb-2 h-12"></div>
        <p class="font-bold text-slate-800">Firma del Docente / Asesor</p>
        <p>Responsable del grupo escolar</p>
      </div>
      <div>
        <div class="w-48 border-b border-slate-400 mx-auto mb-2 h-12"></div>
        <p class="font-bold text-slate-800">Firma de Dirección Académica</p>
        <p>Validador institucional</p>
      </div>
    </section>

  </main>

  <footer class="bg-slate-100 text-center py-6 border-t border-slate-200 mt-20 text-xs text-slate-500">
    <p>© 2026 - Generado de forma autónoma para Control de Evaluación de Alumnos y Asistencia.</p>
  </footer>

</body>
</html>`;
}
